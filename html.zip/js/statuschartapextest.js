	  var optionsAll = {
        series: [{
          name: 'operate',
          type: 'line',
          data: [[1579247496,1],[1579247986,1],[1579247986,1],[1579247986,null],[1579247496,2],[1579247986,2],[1579247986,2],[1579247986,null],[1579247550,3],[1579249550,3],[1579251550,3],[1579252550,3]]
          }, {

          name: 'Alarm',
          type: 'line',
          data: []
		}, {

          name: 'Off',
          type: 'line',
          data: []	
		}],
		
		colors: ['#28A349', '#FA0500', '#6F727D', '#6F727D'],
        chart: {
          type: 'line',
          stacked: false,
          height: 250,
		  toolbar: {
      show: true,
      tools: {
        download: true,
        selection: true,
        zoom: true,
        zoomin: false,
        zoomout: false,
        pan: true,
        reset: true | '<img src="/static/icons/reset.png" width="20">',
        customIcons: []
      },
			},

        },
        plotOptions: {
          line: {
            curve: 'smooth',
          }
        },
        dataLabels: {
          enabled: false
        },
		
		
        xaxis: {
		  type: 'datetime',	
		  labels: {
		  
			datetimeFormatter: {
				year: 'yyyy',
				month: 'MMM \'yy',
				day: 'dd MMM',
				hour: 'HH:mm',
		
			}
		  }
		},
		markers: {
		shape: 'square',
		size: 7
		},	
        yaxis: {
		  showAlways: true,
		  tickAmount: 2,
          max: 2
        },
		
        title: {
          text: 'Loading ..',
          align: 'Center',
		  style: {
			fontSize:  '20px'
			},
        },
		
        tooltip: {
          shared: false,
          intersect: true,

			 
		  x: {
				show: true,
				format: 'dd MMM - HH:mm:ss',
			 },
			 
        },
		
        yaxis: {
		  labels: {
  formatter: function(val, index) {
    if (val == 3) {
        return "Some string";
    }else{
        return val;
    }
  }
      },
		  showAlways: true,
		  tickAmount: 1,
          max: 1
        },
		
        legend: {
		  markers: {
			radius: 2,
		  },
          position: 'bottom',
          horizontalAlign: 'center',
          offsetY: -5
        }
      };

/////////////////////////////////////////////////////////////////////////////////////////
var optionsDay = {
  series: [{
    name: 'operate',
    type: 'line',
    data: []
    }, {

    name: 'Alarm',
    type: 'line',
    data: []
}, {

    name: 'Off',
    type: 'line',
    data: []	
}],

theme: {
mode: 'light' 
},

colors: ['#28A349', '#FA0500', '#6F727D', '#6F727D'],
  chart: {
    type: 'line',
    stacked: false,
    height: 250,
toolbar: {
  show: true,
  tools: {
    download: true,
    selection: true,
    zoom: true,
    zoomin: false,
    zoomout: false,
    pan: true,
    reset: true | '<img src="/static/icons/reset.png" width="20">',
    customIcons: []
  },
  },
},
  plotOptions: {
    line: {
      curve: 'smooth',
    }
  },
  dataLabels: {
    enabled: false
  },


  xaxis: {
type: 'datetime',	
labels: {

datetimeFormatter: {
  year: 'yyyy',
  month: 'MMM \'yy',
  day: 'dd MMM',
  hour: 'HH:mm',

}
}
},
markers: {
shape: 'square',
size: 7
},	
  yaxis: {
showAlways: true,
tickAmount: 2,
    max: 2
  },

  title: {
    text: 'Loading ..',
    align: 'Center',
style: {
fontSize:  '20px'
},
  },

  tooltip: {
    shared: false,
    intersect: true,

 
x: {
  show: true,
  format: 'dd MMM - HH:mm:ss',
 },
 
  },

  yaxis: {
labels: {
formatter: function(val, index) {
if (val == 3) {
  return "Some string";
}else{
  return val;
}
}
},
showAlways: true,
tickAmount: 1,
    max: 1
  },

  legend: {
markers: {
radius: 2,
},
    position: 'bottom',
    horizontalAlign: 'center',
    offsetY: -5
  }
};


/////////////////////////////////////////////////////////////////////////////////////////
var optionsNight = {
  series: [{
    name: 'operate',
    type: 'line',
    data: []
    }, {

    name: 'Alarm',
    type: 'line',
    data: []
}, {

    name: 'Off',
    type: 'line',
    data: []	
}],

theme: {
mode: 'dark' 
},

colors: ['#28A349', '#FA0500', '#6F727D', '#6F727D'],
  chart: {
    type: 'line',
    stacked: false,
    height: 250,
toolbar: {
  show: true,
  tools: {
    download: true,
    selection: true,
    zoom: true,
    zoomin: false,
    zoomout: false,
    pan: true,
    reset: true | '<img src="/static/icons/reset.png" width="20">',
    customIcons: []
  },
  },
},
  plotOptions: {
    line: {
      curve: 'smooth',
    }
  },
  dataLabels: {
    enabled: false
  },


  xaxis: {
type: 'datetime',	
labels: {

datetimeFormatter: {
  year: 'yyyy',
  month: 'MMM \'yy',
  day: 'dd MMM',
  hour: 'HH:mm',

}
}
},
markers: {
shape: 'square',
size: 7
},	
  yaxis: {
showAlways: true,
tickAmount: 2,
    max: 2
  },

  title: {
    text: 'Loading ..',
    align: 'Center',
style: {
fontSize:  '20px'
},
  },

  tooltip: {
    shared: false,
    intersect: true,

 
x: {
  show: true,
  format: 'dd MMM - HH:mm:ss',
 },
 
  },

  yaxis: {
labels: {
formatter: function(val, index) {
if (val == 3) {
  return "Some string";
}else{
  return val;
}
}
},
showAlways: true,
tickAmount: 1,
    max: 1
  },

  legend: {
markers: {
radius: 2,
},
    position: 'bottom',
    horizontalAlign: 'center',
    offsetY: -5
  }
};

//////////////////////////////////////////////
var optionsRunningShift = {
  series: [0],
  chart: {
  height: 270,
  type: 'radialBar',
  },
  colors: ['#007BFF'],
  plotOptions: {
  radialBar: {
    hollow: {
    size: '75%',
    }
  },
  },
labels: ['Loading...'],
};
//////////////////////////////////////////////
var optionsOperateShift = {
  series: [0],
  chart: {
  height: 270,
  type: 'radialBar',
  },
  colors: ['#28A745'],
  plotOptions: {
  radialBar: {
    hollow: {
    size: '75%',
    }
  },
  },
labels: ['Loading...'],
};
//////////////////////////////////////////////
var optionsAlarmShift = {
  series: [0],
  chart: {
  height: 270,
  type: 'radialBar',
  },
  colors: ['#DC3545'],
  plotOptions: {
  radialBar: {
    hollow: {
    size: '75%',
    }
  },
  },
labels: ['Loading...'],
};




//////////////////***/*/*/*/*////////////////// */
//////////////////////////////////////////////
var optionsRunning = {
  series: [0],
  chart: {
  height: 270,
  type: 'radialBar',
  },
  colors: ['#007BFF'],
  plotOptions: {
  radialBar: {
    hollow: {
    size: '75%',
    }
  },
  },
labels: ['Loading...'],
};
//////////////////////////////////////////////
var optionsOperate = {
  series: [0],
  chart: {
  height: 270,
  type: 'radialBar',
  },
  colors: ['#28A745'],
  plotOptions: {
  radialBar: {
    hollow: {
    size: '75%',
    }
  },
  },
labels: ['Loading...'],
};
//////////////////////////////////////////////
var optionsAlarm = {
  series: [0],
  chart: {
  height: 270,
  type: 'radialBar',
  },
  colors: ['#DC3545'],
  plotOptions: {
  radialBar: {
    hollow: {
    size: '75%',
    }
  },
  },
labels: ['Loading...'],
};


//////////////////////////////////////////////////////////////
var chartDay = new ApexCharts(document.querySelector("#chartDay"), optionsDay);
var chartNight = new ApexCharts(document.querySelector("#chartNight"), optionsNight);
var chartAll = new ApexCharts(document.querySelector("#chartAll"), optionsAll);
var chartRunningShift = new ApexCharts(document.querySelector("#chartRunningShift"), optionsRunningShift);
var chartOperateShift = new ApexCharts(document.querySelector("#chartOperateShift"), optionsOperateShift);
var chartAlarmShift = new ApexCharts(document.querySelector("#chartAlarmShift"), optionsAlarmShift);
var chartRunning = new ApexCharts(document.querySelector("#chartRunning"), optionsRunning);
var chartOperate = new ApexCharts(document.querySelector("#chartOperate"), optionsOperate);
var chartAlarm = new ApexCharts(document.querySelector("#chartAlarm"), optionsAlarm);
chartDay.render();
chartNight.render();
chartAll.render();
chartRunningShift.render();
chartOperateShift.render();
chartAlarmShift.render();
chartRunning.render();
chartOperate.render();
chartAlarm.render();