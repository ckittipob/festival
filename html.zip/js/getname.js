function getname() {
	$.ajax({ 
		url: "php/agvname.php?no="+ number ,
		type: "POST",
		data: ''
		})
			.success(function(result1) { 
				var obj = jQuery.parseJSON(result1);
				if(obj != '')
				{
					$.each(obj, function(key, val) {
					agvname = val["agv_name"];
					});												
				}
									
				chart.updateOptions({
					title: {
					text: agvname,
					},
					yaxis: {
						labels: {
						formatter: function(value) {
							if (value == 1) {
								return agvname
								}
							}
						},
					showAlways: true,
					tickAmount: 1,
					max: 1
					}	
				})								
			});	
		}
								
								
								
	function getUrlVars() {
		var vars = {};
		var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
		vars[key] = value;
		});
		return vars;
	}	
	
	
	
	function getchart() {
		chart.updateSeries([{
			name: 'Operate',
			type: 'line',
			data: operate,
			}, {
			name: 'Alarm',
			type: 'line',
			data: [],
			}, {
			name: 'Off',
			type: 'line',
			data: [],
			}])
		getname();
		document.getElementById("haha").innerHTML = operate;
	}
	
	function gendata(){
	
		
										
								$.ajax({ 
											url: "php/agvlog.php?no="+ number + "&from=" + sendfrom +"&to=" + sendto +"&num=" + sendmod ,
											type: "POST",
											data: ''
										})
										.success(function(result1) { 
											var obj = jQuery.parseJSON(result1);
											var check = 'init';
											operate = [];
											alarm = [];
											off = [];
												if(obj != '')
												{
													  //$("#myTable tbody tr:not(:first-child)").remove();
													  $("#homedash").empty();
													  $.each(obj, function(key, val) {
																
																var x = val["stat"];
																var y = val["alarm"];
																var z = parseInt(val["epoch"]);
																fx = x;
																fy = y;
																fz = z;
																var tr = "<tr onclick=\"window.location.href='\"#\">";
																tr = tr + "<td>" + val["created_at"]+"</td>";
																	if(x == 0){
																	 tr = tr + "<td>" + "<span class=\"badge badge-secondary\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																	if(x == 1){
																	 tr = tr + "<td>" + "<span class=\"badge badge-success\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																	if(y == 0){
																	 tr = tr + "<td>" + "<span class=\"badge badge-secondary\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																	if(y == 1){
																	 tr = tr + "<td>" + "<span class=\"badge badge-danger\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																tr = tr + "</tr>";															
																$('#myTable > tbody:last').append(tr);
															//generate data statement
																if (check == 'init'){
																	if((x == 1) && (y == 0)){
																	coperate += 1;
																	operate.push([z, 1]);
																	check = 'operate';
																	}
																	if((x == 1) && (y == 1)){
																	calarm += 1;
																	alarm.push([z, 1]);
																	check = 'alarm';
																	}
																	if((x == 0) && (y == 0)){
																	coff += 1;
																	off.push([z, 1]);
																	check = 'off';
																	}
																	}
																else if (check == 'operate'){
																	if((x == 1) && (y == 0)){
																	coperate += 1;
																	}															
																	if((x == 1) && (y == 1)){
																	calarm += 1;
																	operate.push([z, 1]);
																	alarm.push([z, null]);
																	alarm.push([z, 1]);
																	check = 'alarm';
																	}
																	if((x == 0) && (y == 0)){
																	coff += 1;
																	operate.push([z, 1]);
																	off.push([z, null]);
																	off.push([z, 1]);
																	check = 'off';
																	}
																	}
																else if (check == 'alarm'){
																	if((x == 1) && (y == 0)){
																	coperate += 1;
																	alarm.push([z, 1]);
																	operate.push([z, null]);
																	operate.push([z, 1]);
																	check = 'operate';
																	}
																	if((x == 1) && (y == 1)){
																	calarm += 1;
																	}																
																	if((x == 0) && (y == 0)){
																	coff += 1;
																	alarm.push([z, 1]);
																	off.push([z, null]);
																	off.push([z, 1]);
																	check = 'off';
																	}
																	}
																else if (check == 'off'){																
																	if((x == 1) && (y == 0)){
																	coperate += 1;
																	off.push([z, 1]);
																	operate.push([z, null]);
																	operate.push([z, 1]);
																	check = 'operate';
																	}
																	if((x == 1) && (y == 1)){
																	calarm += 1;
																	off.push([z, 1]);
																	alarm.push([z, null]);
																	alarm.push([z, 1]);
																	check = 'alarm';																
																	}
																	if((x == 0) && (y == 0)){
																	coff += 1;
																	}																
																	}	
																	
	
													  });												
												}
	////////// finalize////////////////
	
		
		if((fx == 1) && (fy == 0)){
		operate.push([fz, 1]);
		}
		if((fx == 1) && (fy == 1)){
		alarm.push([fz, 1]);
		}
		if((fx == 0) && (fy == 0)){
		off.push([fz, 1]);
		}						
	
		perrun = Math.round(((coperate+calarm)*100)/(coperate+calarm+coff));
		perope = Math.round((coperate*100)/(coperate+calarm));
		peralarm = Math.round((calarm*100)/(coperate+calarm));
		
		if (coperate+calarm == 0){
		peralarm = 0;
		perope = 0;
		}

		document.getElementById("running").setAttribute("data-value",perrun);
		document.getElementById('runningtext').innerHTML = perrun+ '%';
		document.getElementById("operate").setAttribute("data-value", perope);
		document.getElementById('operatetext').innerHTML = perope+ '%';
		document.getElementById("alarm").setAttribute("data-value", peralarm);
		document.getElementById('alarmtext').innerHTML = peralarm+ '%';	
		
	
		
		$.getScript( "js/progress.js" )
		.done(function( script, textStatus ) {
		console.log( textStatus );
		})
		.fail(function( jqxhr, settings, exception ) {
		$( "div.log" ).text( "Triggered ajaxError handler." );
		});	
		chart.updateSeries([{
			name: 'Operate',
			type: 'line',
			data: operate,
			}, {
			name: 'Alarm',
			type: 'line',
			data: alarm,
			}, {
			name: 'Off',
			type: 'line',
			data: off,
			}])
		getname();
		
		
	
	
										});	
	}
	
	function emptychart(){
		chart.updateSeries([{
			name: 'Operate',
			type: 'line',
			data: [],
			}, {
			name: 'Alarm',
			type: 'line',
			data: [],
			}, {
			name: 'Off',
			type: 'line',
			data: [],
			}])
		getname();
	}	
	
	function mutealarm(){
	mute = 1;
	//alert('mute');
	}

	function alarmhandle() {
	if (alarm == 1 && mute ==0) {
	//document.getElementById("haha").innerHTML = 'start';
	$('#exampleModal').modal();
	playAudio();// play alarm	
	}

	if (mute ==1) {
	//document.getElementById("jedjed").innerHTML = 'stop';
	pauseAudio(); // stop alarm
	}
	}
	
	
	function playAudio() { 
	  x.play(); 
	} 
	
	function pauseAudio() { 
	  x.pause(); 
	} 
	
	function calalarm(){
		var havealarm = 0;
											for (var k = 0; k <= agvstatall.length ; k++){
	
											if (agvstatall[k] == 1){
												havealarm = 1;
												break; }
											else if (agvstatall[k] == 0){
												havealarm = 0;
												
											}
											}
											if (havealarm == 1){
												alarm = 1;
												alarmreset = 0;
											}
											else if (havealarm == 0){
												alarmreset = 1;
												alarm = 0;
												mute = 0;
												$('#exampleModal').modal('hide');
											}
												alarmhandle();
												//document.getElementById("haha").innerHTML = 'alarm = '+ alarm;
												//document.getElementById("hokhok").innerHTML = 'reset = '+ alarmreset;
												//document.getElementById("jedjed").innerHTML = 'mute = '+ mute;																					
	}
	
							function getDataFromDb()
							{
								$.ajax({ 
											url: "php/agvall.php" ,
											type: "POST",
											data: ''
										})
										.success(function(result1) { 
											var obj = jQuery.parseJSON(result1);
											agvstatall = [];
												if(obj != '')
												{
													  //$("#myTable tbody tr:not(:first-child)").remove();
													  $("#homedash").empty();
													  $.each(obj, function(key, val) {
																var x = val["status"];
																var y = val["alarm"];
																if(val["en"] == 1 &&  globalplant.includes(parseInt(val["plant_id"]))){
																if (x == 2){
																var tr = "<tr class=\"table-danger\" onclick=\"window.location.href='agvlog"+ val["agv_name"]+".html'\">";
																}
																else{
																var tr = "<tr onclick=\"window.location.href='agvlog.html?no=" + val["log"]+ "'\">";
																}
																tr = tr + "<td>" + val["agv_name"]+"</td>";
																	if(x == 0){
																	 tr = tr + "<td>" + "<span class=\"badge badge-secondary\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																	if(x == 1){
																	 tr = tr + "<td>" + "<span class=\"badge badge-success\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																	if(x == 2){
																	 tr = tr + "<td>" + "<span class=\"badge badge-danger\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}																
																	if(y == 0){
																	 tr = tr + "<td>" + "<span class=\"badge badge-secondary\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																	if(y == 1){
																	 tr = tr + "<td>" + "<span class=\"badge badge-danger\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																	}
																agvstatall.push([val["alarm"]]);
																//tr = tr + "<td>" + val["en"]+"</td>";
																tr = tr + "<td>" + val["upd"]+"</td>";
																tr = tr + "</tr>";
																$('#myTable > tbody:last').append(tr);
																}
													  });
													
												}
										//	calalarm();
	
										});
	
							}
	
	