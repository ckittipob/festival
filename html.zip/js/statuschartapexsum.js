
	  var options = {
        series: [{
          name: 'operate',
          type: 'line',
          data: [
		  [1579247496,1],
		  [1579247986,1],
		  [1579247986,1],
		  [1579247986,null],
		  [1579247496,2],
		  [1579247986,2],
		  [1579247986,2],
		  [1579247986,null],
		  [1579248986,2],[1579249986,2],
		  [1579249986,null],
		  [1579247550,3],
		  [1579249550,3],
		  [1579251550,3],
		  [1579252550,3],
		  [1579252550,null]
		  ]
          }, {

          name: 'Alarm',
          type: 'line',
          data: []
		}, {

          name: 'Off',
          type: 'line',
          data: []	
		}],
		
		colors: ['#28A349', '#FA0500', '#6F727D', '#6F727D'],
        chart: {
          type: 'line',
          stacked: false,
          height: 600,
		  toolbar: {
			show: true,
			tools: {
				download: true,
				selection: true,
				zoom: true,
				zoomin: false,
				zoomout: false,
				pan: true,
				reset: true | '<img src="/static/icons/reset.png" width="20">',
				customIcons: []
			  },
			},

        },
        plotOptions: {
          line: {
            curve: 'smooth',
          }
        },
        dataLabels: {
          enabled: false
        },
		
		
        xaxis: {
		  type: 'datetime',	
		  labels: {
		  
			datetimeFormatter: {
				year: 'yyyy',
				month: 'MMM \'yy',
				day: 'dd MMM',
				hour: 'HH:mm',
		
			}
		  }
		},
		markers: {
		shape: 'square',
		size: 7
		},	

		
        title: {
          text: 'Summary',
          align: 'Center',
		  style: {
			fontSize:  '20px'
			},
        },
		
        tooltip: {
          shared: false,
          intersect: true,

			 
		  x: {
				show: true,
				format: 'dd MMM - HH:mm:ss',
			 },
			 
        },
		

		
        legend: {
		  markers: {
			radius: 2,
		  },
          position: 'bottom',
          horizontalAlign: 'center',
          offsetY: -5
        }
      };

      var chart = new ApexCharts(document.querySelector("#chart"), options);
      chart.render();
