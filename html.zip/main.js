// Canvas & Scene Init:
var canvas = document.getElementById("canvas01");
var point = new obelisk.Point(200, 100);
// The center of the scene
var pixelView = new obelisk.PixelView(canvas, point);

// Let's build a grid...
// Setup lines
var lineColor = new obelisk.LineColor();
var dimensionX = new obelisk.LineXDimension(400);
var dimensionY = new obelisk.LineYDimension(200);
var lineX = new obelisk.LineX(dimensionX, lineColor);
var lineY = new obelisk.LineY(dimensionY, lineColor);

// Create Grid:
for (x = 0; x < 28; x++) {
  pixelView.renderObject(lineX, new obelisk.Point3D(0, x * 10, 0));
}
for (y = 0; y < 56; y++) {
  pixelView.renderObject(lineY, new obelisk.Point3D(y * 10, 0, 0));
}

// Create cube:
var cubeColor = new obelisk.CubeColor();
var dimensionCube = new obelisk.CubeDimension(5, 5, 5);
var cube = new obelisk.Cube(dimensionCube, cubeColor, true);

// place cubes:
pixelView.renderObject(cube, new obelisk.Point3D(2, 2, 2));
pixelView.renderObject(cube, new obelisk.Point3D(105, 15, 5));
pixelView.renderObject(cube, new obelisk.Point3D(0, 100, 0));
pixelView.renderObject(cube, new obelisk.Point3D(100, 100, 0))
pixelView.renderObject(cube, new obelisk.Point3D(100, 100, 20));


function getDataFromDb()
						{
							$.ajax({ 
										url: "gelocation.php" ,
										type: "POST",
										data: ''
									})
									.success(function(result) { 
										var obj = jQuery.parseJSON(result);
											if(obj != '')
											{
												  $("#location").empty();
												  $.each(obj, function(key, val) {
															var x = val["stat"];
															if (x == 2){
															var tr = "<tr class=\"table-danger\" onclick=\"window.location.href='agvlog"+ val["agvno"]+".html'\">";
															}
															else{
															var tr = "<tr onclick=\"window.location.href='agvlog"+ val["agvno"]+".html'\">";
															}
															tr = tr + "<td>" + val["agvno"]+"</td>";
																if(x == 0){
																 tr = tr + "<td>" + "<span class=\"badge badge-secondary\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																}
																if(x == 1){
																 tr = tr + "<td>" + "<span class=\"badge badge-success\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																}
																if(x == 2){
																 tr = tr + "<td>" + "<span class=\"badge badge-danger\">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>" + "</td>";
																}																
															tr = tr + "<td>" + val["bat"] + "</td>";
															tr = tr + "</tr>";
															$('#myTable > tbody:last').append(tr);
						  						});
											}

									});

						}