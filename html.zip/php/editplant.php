<?php
$servername = "localhost:3306";
$username = "admin";
$password = "password";
$dbname = "agvstm";
$plantname = $_GET["plantname"];
$plantid = $_GET["plantid"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = " UPDATE plant SET  plant_name = '$plantname' WHERE plant_id = $plantid;";

if ($conn->query($sql) === TRUE) {
	echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
