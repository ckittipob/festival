\<?php
$servername = "localhost:3306";
$username = "jewinwza";
$password = "456654";
$dbname = "agvstm";
$agvname = $_GET["agvname"];
$agvip = $_GET["agvip"];
$agvlog =  $_GET["agvlog"];
$plantid =  $_GET["plantid"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = " ALTER TABLE agvall AUTO_INCREMENT = $agvlog;";

//if ($conn->query($sql) === TRUE) {
	$sql = "INSERT INTO agvall(agv_name,agv_ip,status,alarm,priority,log,en,upd,plant_id) VALUES('$agvname','$agvip',0,0,0,'agvlog$agvname',0,CURRENT_TIMESTAMP(),$plantid);";
	if ($conn->query($sql) === TRUE) {	
		$sql ="CREATE TABLE IF NOT EXISTS agvlog$agvname (
		    log_id INT AUTO_INCREMENT PRIMARY KEY,
    		    stat TINYINT NOT NULL,
    		    alarm TINYINT NOT NULL,
    		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
		)  ENGINE=INNODB;";
		if ($conn->query($sql) === TRUE) {
			echo "New record created successfully";
		}
	}
//} 
else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
