<?php
$servername = "localhost:3306";
$username = "admin";
$password = "password";
$dbname = "agvstm";
$agvname = $_GET["agvname"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "DELETE FROM agvall WHERE agv_id= '$agvname';";

if ($conn->query($sql) === TRUE) {
	$sql = "DROP TABLE agvlogno$agvname;";
	if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	}
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
