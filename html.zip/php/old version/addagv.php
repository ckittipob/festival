<?php
$servername = "localhost:3306";
$username = "root";
$password = "456654";
$dbname = "agvstm";
$agvname = $_GET["agvname"];
$agvip = $_GET["agvip"];
$agvlog =  $_GET["agvlog"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO agvall(agv_name,agv_ip,status,alarm,priority,log,en,upd) VALUES('$agvname','$agvip',0,0,0,'agvlogno1',0,CURRENT_TIMESTAMP());";

if ($conn->query($sql) === TRUE) {
	$sql = "UPDATE agvall 
SET 
    log = (SELECT CONCAT('agvlogno',agv_id) FROM (SELECT * FROM agvall) AS haha WHERE agv_name = '$agvname')
WHERE
    agv_name = '$agvname';";	
    if ($conn->query($sql) === TRUE) {
		$sql = "CREATE TABLE IF NOT EXISTS (SELECT log from agvall where agv_name = '$agvname') (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    stat TINYINT NOT NULL,
    alarm TINYINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
	)  ENGINE=INNODB;";
			if ($conn->query($sql) === TRUE) {
				echo "New record created successfully";			
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}			
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
