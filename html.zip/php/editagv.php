<?php
$servername = "localhost:3306";
$username = "admin";
$password = "password";
$dbname = "agvstm";
$agvname = $_GET["agvname"];
$agvip = $_GET["agvip"];
$agven = $_GET["agven"];
$agvid = $_GET["agvid"];
$plantid =  $_GET["plantid"];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = " UPDATE agvall SET  agv_name = '$agvname', agv_ip = '$agvip', en = $agven, plant_id = $plantid WHERE agv_id = $agvid;";

if ($conn->query($sql) === TRUE) {
	echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
