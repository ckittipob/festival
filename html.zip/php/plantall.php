<?php
	$objConnect = mysqli_connect("localhost:3306","admin","password") or die(mysql_error());
	$objDB = mysqli_select_db($objConnect,"agvstm");
	$strSQL = "SELECT * FROM plant";
	$objQuery = mysqli_query($objConnect,$strSQL) or die (mysqli_error($objConnect));
	$intNumField = mysqli_num_fields($objQuery);
	$resultArray = array();
	while($obResult = mysqli_fetch_array($objQuery))
	{
		$arrCol = array();
		for($i=0;$i<$intNumField;$i++)
		{
			$arrCol[mysqli_field_name($objQuery,$i)] = $obResult[$i];
		}
		array_push($resultArray,$arrCol);
	}
	
	mysqli_close($objConnect);
	
	echo json_encode($resultArray);
	
	function mysqli_field_name($result, $field_offset)
{
    $properties = mysqli_fetch_field_direct($result, $field_offset);
    return is_object($properties) ? $properties->name : null;
}
?>
